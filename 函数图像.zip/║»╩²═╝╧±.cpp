/**
 *                             _ooOoo_
 *                            o8888888o
 *                            88" . "88
 *                            (| -_- |)
 *                            O\  =  /O
 *                         ____/`---'\____
 *                       .'  \\|     |//  `.
 *                      /  \\|||  :  |||//  \
 *                     /  _||||| -:- |||||-  \
 *                     |   | \\\  -  /// |   |
 *                     | \_|  ''\---/''  |   |
 *                     \  .-\__  `-`  ___/-. /
 *                   ___`. .'  /--.--\  `. . __
 *                ."" '<  `.___\_<|>_/___.'  >'"".
 *               | | :  `- \`.;`\ _ /`;.`/ - ` : | |
 *               \  \ `-.   \_ __\ /__ _/   .-` /  /
 *          ======`-.____`-.___\_____/___.-`____.-'======
 *                             `=---='
 *          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *                     ���汣��        ����BUG
**/
#include <iostream>
#include <graphics.h>
#include <string>
#include <cstring>
#include <thread>
#include <fstream>
#include <algorithm>
#include <vector>
#include <list>
#include <stack>
#include <numeric>
#include <Windows.h>
using namespace std;

string function;
const int Max = 100;
int compute(string s, int x);
void paint();

void paint()
{
    int n_x = 0, n_y = 0;
    int t = 0, len = 0;
    int x = -500, y = 0;
    int last_x = 0, last_y = 0;
    bool first = true;
    initgraph(1000, 1000);
    setbkcolor(WHITE);
    setlinecolor(BLACK);
    cleardevice();
    line(500, 0, 500,1000);
    line(0, 500, 1000, 500);
    for (int i = 0; i != 2001; i++)
    {
        
        if (x < 500)
        {
            t = 500 - x;
            t = -t;
            n_x = t;
        }
        if (x >= 500)
        {
            n_x = x - 500;
        }
        n_y = compute(function, n_x);
        if (n_y >= 0) {
            y = 500 - n_y;
        }
        if (n_y < 0)
        {
            t = n_y;
            t = -t;
            y = t + 500;
        }
        if (first == true)
        {
            last_x = x;
            last_y = y;
            first = false;
        }
        cout <<"��" << i << "�� : ��������ʽ : y=" << function << " ;��x=" << n_x << "ʱ,y=" << n_y << endl;
        line(x,y,last_x,last_y);
        last_x = x;
    	last_y = y;
        x += 1;
        y += 1;
    }
    system("pause");
    getchar();
    closegraph();
}
int compute(string s, int x) {
    stack<int> st;
    int num = 0;
    char op = '+';

    for (int i = 0; i < s.length(); i++) {
        if (s[i] == 'x') {
            num = x;
        }
        else if (isdigit(s[i])) {
            num = num * 10 + (s[i] - '0');
        }

        if ((!isdigit(s[i]) && s[i] != 'x' && s[i] != ' ') || i == s.length() - 1) {
            if (op == '+') {
                st.push(num);
            }
            else if (op == '-') {
                st.push(-num);
            }
            else if (op == '*') {
                int temp = st.top();
                st.pop();
                st.push(temp * num);
            }
            else if (op == '/') {
                int temp = st.top();
                st.pop();
                st.push(temp / num);
            }

            op = s[i];
            num = 0;
        }
    }

    int result = 0;
    while (!st.empty()) {
        result += st.top();
        st.pop();
    }

    return result;
}
int main()
{
	cout << "�����뺯������ʽ" << endl << endl;
	cout << "y=";
	cin >> function;
    paint();
	return 0;
}
